﻿using System;

namespace FormatExceptionProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            var continueLoop = true; // keeps the loop running if the application is ran the right way

            do
            {
                try
                {
                    Console.WriteLine("Please enter the miles you have driven");
                    double milesDriven = double.Parse(Console.ReadLine()); // converts string to double 

                    if (milesDriven < 0.0) // if the miles driven input is a negative number 
                    {

                        throw new ArgumentOutOfRangeException("Please enter your miles driven as a positive decimal."); // throw it a out of range exception 
                    }
                    else
                    {
                        milesDriven = milesDriven; // otherwise keep the same value 
                    }

                    double milesPerGallon = 20.00; // i didnt understand how i would calculate the miles per gallon so i gave it its own value and calculated the gallons used instead

                    double gallonsUsed = milesDriven / milesPerGallon; // the calculation for the gallonsUsed

                    Console.WriteLine($"Gallons used: {gallonsUsed}"); // our result displayed as an output

                    continueLoop = false; // break out of the code if we make it out alive without having any error exceptions
                }
                catch (FormatException formatException) // catches error exceptions that are  not in double type
                {
                    Console.WriteLine($"{formatException.Message}"); // displays our error exception message
                    Console.WriteLine("Please enter your amount in decimals"); // tells our user to try their input again 
                }
            } while (continueLoop); // keeps the loop running until the continueLoop variable is set to false on line 34
        }
    }
}
